#!/bin/bash
cd /home/z/my-project
while true; do
  echo "Starting server at $(date)"
  npx next dev -p 3000 2>&1 &
  SERVER_PID=$!
  wait $SERVER_PID 2>/dev/null
  echo "Server died at $(date), restarting in 3s..."
  sleep 3
  rm -rf .next/dev/cache/turbopack 2>/dev/null
done
