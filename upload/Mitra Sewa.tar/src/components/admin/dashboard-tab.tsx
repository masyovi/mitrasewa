"use client";

import {
  DollarSign,
  History,
  HardHat,
  Truck,
  Package,
  AlertTriangle,
} from "lucide-react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import {
  type RentalWithItems,
  type StockData,
} from "@/lib/types";
import { formatCurrency } from "./helpers";

export function DashboardTab({
  stockData,
  rentals,
}: {
  stockData: StockData[];
  rentals: RentalWithItems[];
}) {
  const scaffolding = stockData.find((s) => s.item === "scaffolding");
  const totalAktif = rentals.filter((r) => r.status === "aktif").length;
  const totalKembali = rentals.filter((r) => r.status === "kembali").length;
  const totalPendapatan = rentals.reduce((sum, r) => sum + r.totalHarga, 0);
  const totalPerbaikan = stockData.reduce((sum, s) => sum + s.perbaikan, 0);

  return (
    <div className="space-y-6">
      <div>
        <h2 className="text-xl font-bold text-gray-900">Dashboard</h2>
        <p className="text-sm text-gray-500">
          Ringkasan data penyewaan & stok alat
        </p>
      </div>

      {/* Summary Cards */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-3 sm:gap-4">
        <Card className="border-0 shadow-md">
          <CardContent className="p-4">
            <div className="flex items-center gap-2 mb-2">
              <div className="bg-emerald-100 p-2 rounded-lg">
                <Package className="w-4 h-4 text-emerald-600" />
              </div>
            </div>
            <p className="text-2xl font-bold text-gray-900">
              {scaffolding?.total ?? 0}
            </p>
            <p className="text-xs text-gray-500">Total Scaffolding (Set)</p>
          </CardContent>
        </Card>
        <Card className="border-0 shadow-md">
          <CardContent className="p-4">
            <div className="flex items-center gap-2 mb-2">
              <div className="bg-amber-100 p-2 rounded-lg">
                <Truck className="w-4 h-4 text-amber-600" />
              </div>
            </div>
            <p className="text-2xl font-bold text-gray-900">
              {scaffolding?.disewa ?? 0}
            </p>
            <p className="text-xs text-gray-500">Scaffolding Disewa</p>
          </CardContent>
        </Card>
        <Card className="border-0 shadow-md">
          <CardContent className="p-4">
            <div className="flex items-center gap-2 mb-2">
              <div className="bg-emerald-100 p-2 rounded-lg">
                <Package className="w-4 h-4 text-emerald-600" />
              </div>
            </div>
            <p className="text-2xl font-bold text-gray-900">
              {scaffolding?.tersedia ?? 0}
            </p>
            <p className="text-xs text-gray-500">Scaffolding Tersedia</p>
          </CardContent>
        </Card>
        <Card className="border-0 shadow-md">
          <CardContent className="p-4">
            <div className="flex items-center gap-2 mb-2">
              <div className="bg-blue-100 p-2 rounded-lg">
                <DollarSign className="w-4 h-4 text-blue-600" />
              </div>
            </div>
            <p className="text-2xl font-bold text-gray-900">
              {formatCurrency(totalPendapatan)}
            </p>
            <p className="text-xs text-gray-500">Total Pendapatan</p>
          </CardContent>
        </Card>
      </div>

      {/* Stats Row */}
      <div className="grid grid-cols-3 gap-3 sm:gap-4">
        <Card className="border-0 shadow-md bg-emerald-50">
          <CardContent className="p-4 text-center">
            <p className="text-3xl font-bold text-emerald-700">{totalAktif}</p>
            <p className="text-sm text-emerald-600">Sewa Aktif</p>
          </CardContent>
        </Card>
        <Card className="border-0 shadow-md bg-gray-50">
          <CardContent className="p-4 text-center">
            <p className="text-3xl font-bold text-gray-700">
              {totalKembali}
            </p>
            <p className="text-sm text-gray-600">Sudah Kembali</p>
          </CardContent>
        </Card>
        <Card className={`border-0 shadow-md ${totalPerbaikan > 0 ? "bg-orange-50" : "bg-gray-50"}`}>
          <CardContent className="p-4 text-center">
            <p className={`text-3xl font-bold ${totalPerbaikan > 0 ? "text-orange-700" : "text-gray-700"}`}>
              {totalPerbaikan}
            </p>
            <p className={`text-sm ${totalPerbaikan > 0 ? "text-orange-600" : "text-gray-600"}`}>
              {totalPerbaikan > 0 && <AlertTriangle className="w-3.5 h-3.5 inline mr-0.5" />}
              Perbaikan
            </p>
          </CardContent>
        </Card>
      </div>

      {/* All Stock Overview */}
      <Card className="border-0 shadow-md">
        <CardHeader className="pb-3">
          <CardTitle className="text-base font-bold flex items-center gap-2">
            <HardHat className="w-5 h-5 text-emerald-600" />
            Stok Semua Alat
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="overflow-x-auto">
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>Barang</TableHead>
                  <TableHead className="text-center">Total</TableHead>
                  <TableHead className="text-center">Disewa</TableHead>
                  <TableHead className="text-center">Perbaikan</TableHead>
                  <TableHead className="text-center">Tersedia</TableHead>
                  <TableHead className="text-center">Status</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {stockData.map((item) => (
                  <TableRow key={item.item}>
                    <TableCell className="font-medium">{item.label}</TableCell>
                    <TableCell className="text-center">
                      {item.total} {item.unit}
                    </TableCell>
                    <TableCell className="text-center">
                      <span className="text-amber-600 font-medium">
                        {item.disewa}
                      </span>
                    </TableCell>
                    <TableCell className="text-center">
                      {item.perbaikan > 0 ? (
                        <span className="text-orange-600 font-medium flex items-center justify-center gap-1">
                          <AlertTriangle className="w-3 h-3" />
                          {item.perbaikan}
                        </span>
                      ) : (
                        <span className="text-gray-300">-</span>
                      )}
                    </TableCell>
                    <TableCell className="text-center">
                      <span className="text-emerald-600 font-medium">
                        {item.tersedia}
                      </span>
                    </TableCell>
                    <TableCell className="text-center">
                      <Badge
                        className={
                          item.perbaikan > 0
                            ? "bg-orange-100 text-orange-700"
                            : item.tersedia > 0
                            ? "status-ready"
                            : "bg-red-100 text-red-700"
                        }
                      >
                        {item.perbaikan > 0
                          ? "Perbaikan"
                          : item.tersedia > 0
                          ? "Ready"
                          : "Habis"}
                      </Badge>
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          </div>
        </CardContent>
      </Card>

      {/* Recent Rentals */}
      <Card className="border-0 shadow-md">
        <CardHeader className="pb-3">
          <CardTitle className="text-base font-bold flex items-center gap-2">
            <History className="w-5 h-5 text-emerald-600" />
            Penyewaan Terbaru
          </CardTitle>
        </CardHeader>
        <CardContent>
          {rentals.length === 0 ? (
            <p className="text-center text-gray-400 py-8 text-sm">
              Belum ada data penyewaan
            </p>
          ) : (
            <div className="overflow-x-auto">
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>Penyewa</TableHead>
                    <TableHead className="hidden sm:table-cell">Barang</TableHead>
                    <TableHead>Status</TableHead>
                    <TableHead className="text-right">Total</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {rentals.slice(0, 5).map((r) => (
                    <TableRow key={r.id}>
                      <TableCell>
                        <div>
                          <p className="font-medium text-sm">{r.namaPenyewa}</p>
                          <p className="text-xs text-gray-400">{r.noHp}</p>
                        </div>
                      </TableCell>
                      <TableCell className="hidden sm:table-cell text-sm">
                        {r.items.map((i) => i.label).join(", ")}
                      </TableCell>
                      <TableCell>
                        <Badge
                          className={
                            r.status === "aktif"
                              ? "status-disewa"
                              : "bg-emerald-100 text-emerald-700"
                          }
                        >
                          {r.status === "aktif" ? "Disewa" : "Kembali"}
                        </Badge>
                      </TableCell>
                      <TableCell className="text-right font-medium text-sm">
                        {formatCurrency(r.totalHarga)}
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  );
}
