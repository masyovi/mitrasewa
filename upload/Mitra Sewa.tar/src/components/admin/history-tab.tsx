"use client";

import { useState } from "react";
import {
  Download,
  RotateCcw,
  Trash2,
  Package,
  RefreshCw,
} from "lucide-react";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
  DialogFooter,
  DialogClose,
} from "@/components/ui/dialog";
import { useToast } from "@/hooks/use-toast";
import {
  type RentalWithItems,
} from "@/lib/types";
import { formatCurrency, formatDateShort } from "./helpers";

export function HistoryTab({
  rentals,
  onRefresh,
  onExport,
}: {
  rentals: RentalWithItems[];
  onRefresh: () => void;
  onExport: () => void;
}) {
  const { toast } = useToast();
  const [search, setSearch] = useState("");
  const [filterStatus, setFilterStatus] = useState<
    "semua" | "aktif" | "kembali"
  >("semua");

  const filteredRentals = rentals.filter((r) => {
    const matchSearch =
      r.namaPenyewa.toLowerCase().includes(search.toLowerCase()) ||
      r.noHp.includes(search) ||
      r.alamat.toLowerCase().includes(search.toLowerCase());
    const matchStatus =
      filterStatus === "semua" || r.status === filterStatus;
    return matchSearch && matchStatus;
  });

  const handleReturn = async (id: string, nama: string) => {
    try {
      const res = await fetch("/api/rentals", {
        method: "PATCH",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ id, status: "kembali" }),
      });
      const data = await res.json();
      if (data.success) {
        toast({
          title: "Berhasil",
          description: `Barang dari ${nama} telah dikembalikan`,
        });
        onRefresh();
      } else {
        toast({
          title: "Gagal",
          description: data.message,
          variant: "destructive",
        });
      }
    } catch {
      toast({
        title: "Error",
        description: "Gagal mengupdate status",
        variant: "destructive",
      });
    }
  };

  const handleDelete = async (id: string) => {
    try {
      const res = await fetch(`/api/rentals?id=${id}`, {
        method: "DELETE",
      });
      const data = await res.json();
      if (data.success) {
        toast({ title: "Berhasil", description: "Data berhasil dihapus" });
        onRefresh();
      } else {
        toast({
          title: "Gagal",
          description: data.message,
          variant: "destructive",
        });
      }
    } catch {
      toast({
        title: "Error",
        description: "Gagal menghapus data",
        variant: "destructive",
      });
    }
  };

  return (
    <div className="space-y-6">
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-3">
        <div>
          <h2 className="text-xl font-bold text-gray-900">
            History Penyewaan
          </h2>
          <p className="text-sm text-gray-500">
            {filteredRentals.length} data penyewaan
          </p>
        </div>
        <div className="flex gap-2">
          <Button
            variant="outline"
            size="sm"
            onClick={onRefresh}
            className="gap-1.5"
          >
            <RefreshCw className="w-3.5 h-3.5" />
            Refresh
          </Button>
          <Button
            size="sm"
            onClick={onExport}
            className="gap-1.5 bg-emerald-600 hover:bg-emerald-700"
          >
            <Download className="w-3.5 h-3.5" />
            Export CSV
          </Button>
        </div>
      </div>

      {/* Search & Filter */}
      <div className="flex flex-col sm:flex-row gap-3">
        <Input
          placeholder="Cari nama, no HP, alamat..."
          value={search}
          onChange={(e) => setSearch(e.target.value)}
          className="flex-1"
        />
        <div className="flex gap-2">
          {(["semua", "aktif", "kembali"] as const).map((status) => (
            <Button
              key={status}
              variant={filterStatus === status ? "default" : "outline"}
              size="sm"
              onClick={() => setFilterStatus(status)}
              className={
                filterStatus === status
                  ? "bg-emerald-600 hover:bg-emerald-700"
                  : ""
              }
            >
              {status === "semua"
                ? "Semua"
                : status === "aktif"
                  ? "Disewa"
                  : "Kembali"}
            </Button>
          ))}
        </div>
      </div>

      {/* Results */}
      {filteredRentals.length === 0 ? (
        <Card className="border-0 shadow-md">
          <CardContent className="py-12 text-center">
            <Package className="w-12 h-12 text-gray-300 mx-auto mb-3" />
            <p className="text-gray-500 text-sm">
              {search || filterStatus !== "semua"
                ? "Tidak ada data yang cocok"
                : "Belum ada data penyewaan"}
            </p>
          </CardContent>
        </Card>
      ) : (
        <div className="space-y-4">
          {filteredRentals.map((rental) => (
            <Card key={rental.id} className="border-0 shadow-md overflow-hidden">
              <CardContent className="p-0">
                {/* Header */}
                <div className="flex items-center justify-between p-4 pb-3 border-b border-gray-50">
                  <div>
                    <h4 className="font-bold text-gray-900">
                      {rental.namaPenyewa}
                    </h4>
                    <div className="flex flex-wrap gap-2 mt-1">
                      <span className="text-xs text-gray-500">
                        {rental.noHp}
                      </span>
                      <span className="text-xs text-gray-400">•</span>
                      <span className="text-xs text-gray-500">
                        {rental.alamat}
                      </span>
                    </div>
                  </div>
                  <Badge
                    className={
                      rental.status === "aktif"
                        ? "status-disewa"
                        : "bg-emerald-100 text-emerald-700"
                    }
                  >
                    {rental.status === "aktif" ? "Disewa" : "Kembali"}
                  </Badge>
                </div>

                {/* Items */}
                <div className="p-4 pb-2">
                  <div className="overflow-x-auto">
                    <table className="w-full text-sm">
                      <thead>
                        <tr className="text-xs text-gray-500 border-b border-gray-100">
                          <th className="text-left py-1.5 font-medium">Barang</th>
                          <th className="text-center py-1.5 font-medium">Qty</th>
                          <th className="text-right py-1.5 font-medium hidden sm:table-cell">
                            Harga
                          </th>
                          <th className="text-center py-1.5 font-medium hidden sm:table-cell">
                            Durasi
                          </th>
                          <th className="text-right py-1.5 font-medium">
                            Subtotal
                          </th>
                        </tr>
                      </thead>
                      <tbody>
                        {rental.items.map((item) => (
                          <tr
                            key={item.id}
                            className="border-b border-gray-50 last:border-0"
                          >
                            <td className="py-2">{item.label}</td>
                            <td className="text-center py-2">
                              {item.jumlah}
                            </td>
                            <td className="text-right py-2 hidden sm:table-cell text-gray-500">
                              <div>{formatCurrency(item.harga)}</div>
                              <div className="text-[10px] text-gray-400">
                                /{item.billingType === "bulanan" ? "bulan" : "hari"}
                              </div>
                            </td>
                            <td className="text-center py-2 hidden sm:table-cell text-xs text-gray-500">
                              {item.billingType === "bulanan"
                                ? `${item.multiplier} bln`
                                : `${item.multiplier} hr`}
                            </td>
                            <td className="text-right py-2 font-medium">
                              {formatCurrency(item.subtotal)}
                            </td>
                          </tr>
                        ))}
                      </tbody>
                    </table>
                  </div>
                </div>

                {/* Footer */}
                <div className="flex flex-col sm:flex-row sm:items-center justify-between p-4 pt-2 gap-3 bg-gray-50/50">
                  <div className="text-xs text-gray-500 space-y-0.5">
                    <p>
                      Sewa:{" "}
                      {formatDateShort(rental.tanggalSewa)} →{" "}
                      {formatDateShort(rental.tanggalKembali)} ({rental.lamaSewa}{" "}
                      hari)
                    </p>
                    <p className="text-[10px] text-gray-400">
                      Dibuat: {formatDateShort(rental.createdAt)}
                    </p>
                  </div>
                  <div className="flex items-center gap-2">
                    <div className="text-right">
                      <p className="text-[10px] text-gray-400">Total</p>
                      <p className="font-bold text-emerald-700 text-sm">
                        {formatCurrency(rental.totalHarga)}
                      </p>
                    </div>
                    {rental.status === "aktif" && (
                      <Dialog>
                        <DialogTrigger asChild>
                          <Button
                            size="sm"
                            variant="outline"
                            className="gap-1 text-xs h-8 border-emerald-200 text-emerald-700 hover:bg-emerald-50"
                          >
                            <RotateCcw className="w-3 h-3" />
                            Kembali
                          </Button>
                        </DialogTrigger>
                        <DialogContent>
                          <DialogHeader>
                            <DialogTitle>Konfirmasi Pengembalian</DialogTitle>
                          </DialogHeader>
                          <p className="text-sm text-gray-600">
                            Apakah barang dari <strong>{rental.namaPenyewa}</strong>{" "}
                            sudah dikembalikan?
                          </p>
                          <DialogFooter className="gap-2">
                            <DialogClose asChild>
                              <Button variant="outline" size="sm">
                                Batal
                              </Button>
                            </DialogClose>
                            <DialogClose asChild>
                              <Button
                                size="sm"
                                className="bg-emerald-600 hover:bg-emerald-700"
                                onClick={() =>
                                  handleReturn(rental.id, rental.namaPenyewa)
                                }
                              >
                                Ya, Kembalikan
                              </Button>
                            </DialogClose>
                          </DialogFooter>
                        </DialogContent>
                      </Dialog>
                    )}
                    <Dialog>
                      <DialogTrigger asChild>
                        <Button
                          size="sm"
                          variant="ghost"
                          className="gap-1 text-xs h-8 text-red-500 hover:text-red-700 hover:bg-red-50"
                        >
                          <Trash2 className="w-3 h-3" />
                        </Button>
                      </DialogTrigger>
                      <DialogContent>
                        <DialogHeader>
                          <DialogTitle>Hapus Data</DialogTitle>
                        </DialogHeader>
                        <p className="text-sm text-gray-600">
                          Yakin ingin menghapus data penyewaan{" "}
                          <strong>{rental.namaPenyewa}</strong>? Tindakan ini
                          tidak dapat dibatalkan.
                        </p>
                        <DialogFooter className="gap-2">
                          <DialogClose asChild>
                            <Button variant="outline" size="sm">
                              Batal
                            </Button>
                          </DialogClose>
                          <DialogClose asChild>
                            <Button
                              size="sm"
                              variant="destructive"
                              onClick={() => handleDelete(rental.id)}
                            >
                              Hapus
                            </Button>
                          </DialogClose>
                        </DialogFooter>
                      </DialogContent>
                    </Dialog>
                  </div>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
      )}
    </div>
  );
}
