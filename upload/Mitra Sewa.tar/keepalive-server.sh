#!/bin/bash
cd /home/z/my-project
while true; do
  # Check if server is running
  RESP=$(curl -s -o /dev/null -w "%{http_code}" http://localhost:3000/ 2>/dev/null)
  if [ "$RESP" != "200" ]; then
    # Kill any leftover processes
    pkill -f "next dev" 2>/dev/null
    pkill -f "bun.*dev" 2>/dev/null
    sleep 2
    # Clear cache and start fresh
    rm -rf .next
    echo "[$(date)] Restarting server..." >> dev.log
    bun run dev >> dev.log 2>&1 &
  fi
  sleep 8
done
