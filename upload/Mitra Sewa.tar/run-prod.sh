#!/bin/bash
cd /home/z/my-project/.next/standalone
while true; do
  RESP=$(curl -s -o /dev/null -w "%{http_code}" http://localhost:3000/ 2>/dev/null || echo "000")
  if [ "$RESP" != "200" ]; then
    pkill -f "node server.js" 2>/dev/null
    sleep 1
    DATABASE_URL="file:/home/z/my-project/db/custom.db" node server.js -p 3000 >> /home/z/my-project/server.log 2>&1 &
    sleep 3
  fi
  sleep 5
done
