import type { NextConfig } from "next";

const nextConfig: NextConfig = {
  output: "standalone",
  typescript: {
    ignoreBuildErrors: true,
  },
  reactStrictMode: false,
  // Disable turbopack - use webpack for stability
  serverExternalPackages: ["@prisma/client", "prisma"],
};

export default nextConfig;
