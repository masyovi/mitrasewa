#!/bin/bash
# Keepalive script for MITRA SEWA dev server
cd /home/z/my-project
export DATABASE_URL="file:/home/z/my-project/db/custom.db"

while true; do
    # Check if port 3000 is listening
    if ! ss -tlnp 2>/dev/null | grep -q ':3000'; then
        # Clean up
        pkill -f "next-server" 2>/dev/null
        pkill -f "bun.*dev" 2>/dev/null
        rm -rf .next node_modules/.cache 2>/dev/null
        echo "[$(date)] Starting server..." >> /home/z/my-project/keepalive.log
        # Start server
        bun run dev >> /home/z/my-project/dev.log 2>&1 &
        sleep 15
    fi
    sleep 10
done
