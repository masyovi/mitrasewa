#!/bin/bash
cd /home/z/my-project
while true; do
  echo "=== Starting dev server at $(date) ==="
  rm -rf .next/dev/cache/turbopack 2>/dev/null
  bun run dev 2>&1 &
  PID=$!
  # Wait for process to exit
  wait $PID 2>/dev/null
  EXIT_CODE=$?
  echo "=== Server exited with code $EXIT_CODE at $(date), restarting in 2s... ==="
  sleep 2
done
