#!/bin/bash
pkill -f "bun.*dev\|node.*server" 2>/dev/null
sleep 1
cd /home/z/my-project
rm -rf .next
nohup bun run dev > dev.log 2>&1 &
disown
